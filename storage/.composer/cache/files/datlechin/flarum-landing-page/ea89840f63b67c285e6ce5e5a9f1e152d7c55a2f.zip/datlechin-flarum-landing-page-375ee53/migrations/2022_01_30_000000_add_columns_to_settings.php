<?php

use Flarum\Database\Migration;

return Migration::addSettings([
    'datlechin-landing-page.header_html' => null,
    'datlechin-landing-page.body_html' => null,
]);
